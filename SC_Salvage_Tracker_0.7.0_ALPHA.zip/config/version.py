APP_NAME = "SC Salvage Tracker"

APP_VERSION = "0.6.0 Alpha"
APP_BUILD = "2025.10"