from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QComboBox
)

from database.database import Database


class SalesPage(QWidget):

    def __init__(self):

        super().__init__()

        main_layout = QVBoxLayout()

        title = QLabel("VERKÄUFE")
        title.setObjectName("pageTitle")

        self.session_combo = QComboBox()
        
        self.rmc_amount_label = QLabel(
            "RMC SCU: 0"
        )

        self.cm_amount_label = QLabel(
            "CM SCU: 0"
        )

        self.rmc_price_input = QLineEdit()
        self.rmc_price_input.setPlaceholderText(
            "RMC Verkaufspreis pro SCU"
        )

        self.cm_price_input = QLineEdit()
        self.cm_price_input.setPlaceholderText(
            "CM Verkaufspreis pro SCU"
        )

        self.calculate_button = QPushButton(
            "Gewinn berechnen"
        )

        self.finish_button = QPushButton(
            "Als verkauft markieren"
        )
        
        self.rmc_revenue_label = QLabel(
            "RMC Umsatz: 0 aUEC"
        )

        self.cm_revenue_label = QLabel(
            "CM Umsatz: 0 aUEC"
        )

        self.total_revenue_label = QLabel(
            "Gesamtumsatz: 0 aUEC"
        )

        self.total_costs_label = QLabel(
            "Gesamtkosten: 0 aUEC"
        )

        self.profit_label = QLabel(
            "Gewinn: 0 aUEC"
        )

        main_layout.addWidget(title)

        main_layout.addWidget(
            QLabel("Session")
        )
        main_layout.addWidget(
            self.session_combo
        )
        
        main_layout.addWidget(
            self.rmc_amount_label
        )

        main_layout.addWidget(
            self.cm_amount_label
        )

        main_layout.addWidget(
            QLabel("RMC Preis")
        )
        main_layout.addWidget(
            self.rmc_price_input
        )

        main_layout.addWidget(
            QLabel("CM Preis")
        )
        main_layout.addWidget(
            self.cm_price_input
        )

        main_layout.addWidget(
            self.calculate_button
        )

        main_layout.addWidget(
            self.rmc_revenue_label
        )

        main_layout.addWidget(
            self.cm_revenue_label
        )

        main_layout.addWidget(
            self.total_revenue_label
        )

        main_layout.addWidget(
            self.total_costs_label
        )

        main_layout.addWidget(
            self.profit_label
        )

        main_layout.addWidget(
            self.finish_button
        )

        main_layout.addStretch()

        self.setLayout(main_layout)

        self.load_sessions()

        self.session_combo.currentIndexChanged.connect(
            self.load_materials
        )
        
        self.calculate_button.clicked.connect(
            self.calculate_profit
        )
        
        self.finish_button.clicked.connect(
            self.mark_as_sold
        )
        
    def load_sessions(self):

        self.session_combo.clear()

        db = Database()

        db.cursor.execute("""
        SELECT
            sessions.id
        FROM sessions
        WHERE sessions.status != 'SOLD'
        AND (
            EXISTS(
                SELECT 1
                FROM session_materials
                WHERE session_materials.session_id = sessions.id
                AND material_type = 'RMC'
                AND amount > 0
            )
            OR
            EXISTS(
                SELECT 1
                FROM session_materials
                WHERE session_materials.session_id = sessions.id
                AND material_type = 'CM'
                AND amount > 0
            )
        )
        ORDER BY sessions.id DESC
        """)

        sessions = db.cursor.fetchall()

        for session in sessions:

            self.session_combo.addItem(
                f"Session #{session[0]}",
                session[0]
            )
            
        if self.session_combo.count() > 0:

            self.load_materials()

        else:

            self.rmc_amount_label.setText(
                "RMC SCU: 0"
            )

            self.cm_amount_label.setText(
                "CM SCU: 0"
            )

            self.reset_calculation_labels()

    def load_materials(self):

        session_id = self.session_combo.currentData()

        if session_id is None:
            return

        db = Database()

        rmc = db.get_material_total(
            session_id,
            "RMC"
        )

        cm = db.get_material_total(
            session_id,
            "CM"
        )

        self.rmc_amount_label.setText(
            f"RMC SCU: {rmc:,.0f}"
        )

        self.cm_amount_label.setText(
            f"CM SCU: {cm:,.0f}"
        )
        
        self.reset_calculation_labels()
        
    def reset_calculation_labels(self):

        self.rmc_revenue_label.setText(
            "RMC Umsatz: 0 aUEC"
        )

        self.cm_revenue_label.setText(
            "CM Umsatz: 0 aUEC"
        )

        self.total_revenue_label.setText(
            "Gesamtumsatz: 0 aUEC"
        )

        self.total_costs_label.setText(
            "Gesamtkosten: 0 aUEC"
        )

        self.profit_label.setText(
            "Gewinn: 0 aUEC"
        )
        
    def calculate_profit(self):

        try:
            rmc_price = float(
                self.rmc_price_input.text() or 0
            )

            cm_price = float(
                self.cm_price_input.text() or 0
            )

        except ValueError:
            return

        session_id = self.session_combo.currentData()

        if session_id is None:
            return

        db = Database()

        rmc_scu = db.get_material_total(
            session_id,
            "RMC"
        )

        cm_scu = db.get_material_total(
            session_id,
            "CM"
        )

        rmc_revenue = rmc_scu * rmc_price
        cm_revenue = cm_scu * cm_price

        total_revenue = (
            rmc_revenue +
            cm_revenue
        )

        self.rmc_revenue_label.setText(
            f"RMC Umsatz: {rmc_revenue:,.0f} aUEC"
        )

        self.cm_revenue_label.setText(
            f"CM Umsatz: {cm_revenue:,.0f} aUEC"
        )

        self.total_revenue_label.setText(
            f"Gesamtumsatz: {total_revenue:,.0f} aUEC"
        )
        
        total_costs = db.get_total_costs(
            session_id
        )

        profit = (
            total_revenue -
            total_costs
        )

        self.total_costs_label.setText(
            f"Gesamtkosten: {total_costs:,.0f} aUEC"
        )

        self.profit_label.setText(
            f"Gewinn: {profit:,.0f} aUEC"
        )
        
    def mark_as_sold(self):

        session_id = self.session_combo.currentData()

        if session_id is None:
            return

        db = Database()

        sale_value = 0

        try:

            sale_value = float(
                self.total_revenue_label.text()
                .replace(
                    "Gesamtumsatz: ",
                    ""
                )
                .replace(
                    " aUEC",
                    ""
                )
                .replace(
                    ",",
                    ""
                )
            )

        except ValueError:

            return

        db.mark_session_sold(
            session_id,
            sale_value
        )

        self.load_sessions()