from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QVBoxLayout,
    QLineEdit,
    QPushButton,
    QComboBox
)


class RunCompletionPage(QWidget):

    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        title = QLabel("RUN ABSCHLIESSEN")
        title.setObjectName("pageTitle")

        self.rmc_input = QLineEdit()
        self.rmc_input.setPlaceholderText("RMC SCU")

        self.cms_input = QLineEdit()
        self.cms_input.setPlaceholderText("CMS SCU")

        self.mission_cost_input = QLineEdit()
        self.mission_cost_input.setPlaceholderText(
            "Missionskosten aUEC"
        )

        self.mission_owner_combo = QComboBox()

        self.finish_button = QPushButton(
            "Run abschließen"
        )

        layout.addWidget(title)

        layout.addWidget(QLabel("RMC"))
        layout.addWidget(self.rmc_input)

        layout.addWidget(QLabel("CMS"))
        layout.addWidget(self.cms_input)

        layout.addWidget(QLabel("Missionskosten"))
        layout.addWidget(self.mission_cost_input)

        layout.addWidget(QLabel("Missionsgeber"))
        layout.addWidget(self.mission_owner_combo)

        layout.addWidget(self.finish_button)

        layout.addStretch()

        self.setLayout(layout)