from datetime import datetime

from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QVBoxLayout,
    QPushButton,
    QComboBox,
    QMessageBox,
    QTextEdit,
    QLineEdit
)

from database.database import Database


class SessionPage(QWidget):

    def __init__(self):
        super().__init__()

        self.db = Database()

        layout = QVBoxLayout()

        title = QLabel("SESSION MANAGER")
        title.setObjectName("pageTitle")

        # -----------------------------
        # Session starten
        # -----------------------------

        start_title = QLabel("◆ NEUE SESSION")

        start_title.setStyleSheet("""
            color: #00D9FF;
            font-family: Orbitron;
            font-size: 18px;
            font-weight: bold;
        """)

        self.ship_combo = QComboBox()
        self.ship_combo.addItems([
            "RSI Salvation",
            "MISC Fortune",
            "Drake Vulture",
            "ARGO MOTH",
            "Aegis Reclaimer"
        ])
        
        self.ship_combo.currentTextChanged.connect(
            self.update_material_inputs
        )

        self.crew_input = QTextEdit()

        self.crew_input.setPlaceholderText(
            "Ein Name pro Zeile\n\n"
            "Beispiel:\n"
            "Xangandu\n"
            "Pilot2\n"
            "Pilot3"
        )

        self.start_button = QPushButton(
            "Session starten"
        )

        self.start_button.clicked.connect(
            self.start_session
        )

        # -----------------------------
        # Aktive Session
        # -----------------------------

        active_title = QLabel("◆ AKTIVE SESSION")

        active_title.setStyleSheet("""
            color: #00D9FF;
            font-family: Orbitron;
            font-size: 18px;
            font-weight: bold;
        """)

        self.active_ship_label = QLabel(
            "Schiff: Keine aktive Session"
        )

        self.active_status_label = QLabel(
            "Status: Wartet auf Session"
        )

        # -----------------------------
        # Materialien erfassen
        # -----------------------------

        finish_title = QLabel("◆ MATERIALIEN ERFASSEN")

        finish_title.setStyleSheet("""
            color: #00D9FF;
            font-family: Orbitron;
            font-size: 18px;
            font-weight: bold;
        """)

        self.rmc_input = QLineEdit()
        self.rmc_input.setPlaceholderText("RMC SCU")

        self.cm_rubble_input = QLineEdit()
        self.cm_rubble_input.setPlaceholderText(
            "CM Rubble SCU"
        )

        self.cm_scraps_input = QLineEdit()
        self.cm_scraps_input.setPlaceholderText(
            "CM Scraps SCU"
        )

        self.cm_salvage_input = QLineEdit()
        self.cm_salvage_input.setPlaceholderText(
            "CM Salvage SCU"
        )
        
        self.finish_button = QPushButton(
            "Run speichern"
        )

        self.end_session_button = QPushButton(
            "Session beenden"
        )

        self.end_session_button.clicked.connect(
            self.end_session
        )

        self.end_session_button.setEnabled(
            False
        )

        self.finish_button.clicked.connect(
            self.complete_run
        )

        self.finish_button.setEnabled(False)

        # -----------------------------
        # Layout
        # -----------------------------

        layout.addWidget(title)

        layout.addSpacing(20)

        layout.addWidget(start_title)
        layout.addSpacing(10)

        layout.addWidget(QLabel("Schiff"))
        layout.addWidget(self.ship_combo)

        layout.addWidget(QLabel("Crew"))
        layout.addWidget(self.crew_input)
        
        layout.addWidget(
            QLabel("Missionskosten")
        )

        self.mission_cost_input = QLineEdit()

        self.mission_cost_input.setPlaceholderText(
            "z.B. 10000"
        )

        layout.addWidget(
            self.mission_cost_input
        )

        layout.addWidget(self.start_button)

        layout.addSpacing(40)

        layout.addWidget(active_title)
        layout.addSpacing(10)

        layout.addWidget(self.active_ship_label)
        layout.addWidget(self.active_status_label)

        layout.addSpacing(40)

        layout.addWidget(finish_title)
        layout.addSpacing(10)

        layout.addWidget(QLabel("RMC"))
        layout.addWidget(self.rmc_input)

        layout.addWidget(QLabel("CM Rubble"))
        layout.addWidget(self.cm_rubble_input)

        layout.addWidget(QLabel("CM Scraps"))
        layout.addWidget(self.cm_scraps_input)

        layout.addWidget(QLabel("CM Salvage"))
        layout.addWidget(self.cm_salvage_input)

        layout.addWidget(self.finish_button)

        layout.addWidget(
            self.end_session_button
        )

        layout.addStretch()

        self.setLayout(layout)

        self.refresh_session()
        self.update_material_inputs()
        
    def update_material_inputs(self):

        ship = self.ship_combo.currentText()

        self.rmc_input.setEnabled(False)
        self.cm_rubble_input.setEnabled(False)
        self.cm_scraps_input.setEnabled(False)
        self.cm_salvage_input.setEnabled(False)

        if ship == "RSI Salvation":

            self.rmc_input.setEnabled(True)
            self.cm_rubble_input.setEnabled(True)

        elif ship == "Aegis Reclaimer":

            self.rmc_input.setEnabled(True)
            self.cm_salvage_input.setEnabled(True)

        elif ship == "Drake Vulture":

            self.cm_rubble_input.setEnabled(True)

        elif ship == "MISC Fortune":

            self.cm_rubble_input.setEnabled(True)

        elif ship == "ARGO MOTH":

            self.cm_scraps_input.setEnabled(True)
            
        for field in [
            self.rmc_input,
            self.cm_rubble_input,
            self.cm_scraps_input,
            self.cm_salvage_input
        ]:

                if field.isEnabled():

                    field.setStyleSheet("""
                        color: #FFFFFF;
                        background-color: #08131C;
                    """)

                else:

                    field.setStyleSheet("""
                        color: #555555;
                        background-color: #030507;
                    """)
            
    def refresh_session(self):

        session = self.db.get_active_session()

        if not session:

            self.active_ship_label.setText(
                "Schiff: Keine aktive Session"
            )

            self.active_status_label.setText(
                "Status: Keine aktive Session"
            )

            self.finish_button.setEnabled(
                False
            )

            self.end_session_button.setEnabled(
                False
            )

            return

        self.active_ship_label.setText(
            f"Schiff: {session[1]}"
        )

        self.active_status_label.setText(
            f"Status: {session[2]}"
        )

        self.finish_button.setEnabled(
            session[2] == "ACTIVE"
        )

        self.end_session_button.setEnabled(
        session[2] == "ACTIVE"
        )

    def start_session(self):

        ship = self.ship_combo.currentText()

        try:

            mission_cost = int(
                self.mission_cost_input.text() or 0
            )

        except ValueError:

            QMessageBox.warning(
                self,
                "Fehler",
                "Bitte gültige Missionskosten eingeben"
            )

            return

        start_time = datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        session_id = self.db.create_session(
            ship,
            start_time
        )

        crew_text = self.crew_input.toPlainText()

        crew_members = [
            member.strip()
            for member in crew_text.splitlines()
            if member.strip()
        ]

        for member in crew_members:
            self.db.add_crew_member(
                session_id,
                member
            )
            
            if mission_cost > 0:

                self.db.add_cost(
                    session_id,
                    "Mission",
                    mission_cost,
                    "SYSTEM"
                )

        self.active_ship_label.setText(
            f"Schiff: {ship}"
        )

        self.active_status_label.setText(
            "Status: ACTIVE"
        )

        self.finish_button.setEnabled(True)

        self.end_session_button.setEnabled(True)
        
        self.mission_cost_input.clear()
        
        main_window = self.window()

        if hasattr(
            main_window,
            "dashboard_page"
        ):

            main_window.dashboard_page.refresh_dashboard()

        QMessageBox.information(
            self,
            "Session gestartet",
            "Die Salvage-Session wurde gestartet."
        )

    def complete_run(self):

        session = self.db.get_active_session()

        if not session:

            QMessageBox.warning(
                self,
                "Fehler",
                "Keine aktive Session gefunden"
            )
            return

        try:

            rmc = float(
                self.rmc_input.text() or 0
            )

            cm_rubble = float(
                self.cm_rubble_input.text() or 0
            )

            cm_scraps = float(
                self.cm_scraps_input.text() or 0
            )

            cm_salvage = float(
                self.cm_salvage_input.text() or 0
            )

        except ValueError:

            QMessageBox.warning(
                self,
                "Fehler",
                "Bitte gültige Zahlen eingeben"
            )
            return
        
        self.db.add_material(
            session[0],
            "RMC",
            rmc
        )

        self.db.add_material(
            session[0],
            "CM_RUBBLE",
            cm_rubble
        )

        self.db.add_material(
            session[0],
            "CM_SCRAPS",
            cm_scraps
        )

        self.db.add_material(
            session[0],
            "CM_SALVAGE",
            cm_salvage
        )

        self.rmc_input.clear()
        self.cm_rubble_input.clear()
        self.cm_scraps_input.clear()
        self.cm_salvage_input.clear()

        self.refresh_session()
        
        main_window = self.window()

        if hasattr(
            main_window,
            "dashboard_page"
        ):

            main_window.dashboard_page.refresh_dashboard()

        QMessageBox.information(
            self,
            "Erfolg",
            "Materialien gespeichert"
        )
    def end_session(self):

        session = self.db.get_active_session()

        if not session:

            QMessageBox.warning(
                self,
                "Fehler",
                "Keine aktive Session gefunden"
            )
            return

        self.db.end_session(
            session[0]
        )

        self.refresh_session()

        main_window = self.window()

        if hasattr(
            main_window,
            "dashboard_page"
        ):

            main_window.dashboard_page.refresh_dashboard()

        QMessageBox.information(
            self,
            "Session beendet",
            "Die Session wartet nun auf die Raffinerie."
        )