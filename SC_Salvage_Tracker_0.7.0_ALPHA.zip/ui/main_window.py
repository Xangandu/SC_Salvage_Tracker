from ui.session_page import SessionPage
from ui.salvage_page import SalvagePage
from ui.statistics_page import StatisticsPage
from ui.history_page import HistoryPage
from PySide6.QtCore import Qt
from ui.refinery_page import RefineryPage
from ui.sales_page import SalesPage
from ui.changelog_dialog import (
    ChangelogDialog
)

from config.version import (
    APP_NAME,
    APP_VERSION,
    APP_BUILD
)

from PySide6.QtWidgets import (
    QMainWindow,
    QWidget,
    QHBoxLayout,
    QVBoxLayout,
    QPushButton,
    QLabel,
    QStackedWidget
)

from ui.dashboard_page import DashboardPage

from ui.dashboard_window import (
    DashboardWindow
)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("MobiGlas Salvage Tracker")
        self.resize(1600, 900)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout()
        central_widget.setLayout(main_layout)

        # Navigation
        nav_widget = QWidget()
        nav_widget.setObjectName("navPanel")
        nav_widget.setMinimumWidth(280)
        nav_widget.setMaximumWidth(320)

        nav_layout = QVBoxLayout()
        nav_widget.setLayout(nav_layout)
        nav_layout.setSpacing(12)
        nav_layout.setContentsMargins(
            15,
            20,
            15,
            20
        )

        title = QLabel("MOBIGLAS")
        title.setObjectName("navTitle")

        # Buttons
        self.btn_dashboard = QPushButton(
            "Dashboard ⧉"
        )
        self.btn_dashboard.setObjectName(
            "navButton"
        )

        self.btn_session = QPushButton("Session")
        self.btn_session.setObjectName("navButton")

        self.btn_refinery = QPushButton("Refinery")
        self.btn_refinery.setObjectName("navButton")
        
        self.btn_sales = QPushButton("Verkäufe")
        self.btn_sales.setObjectName("navButton")

        self.btn_stats = QPushButton("Statistik")
        self.btn_stats.setObjectName("navButton")

        self.btn_history = QPushButton("Historie")
        self.btn_history.setObjectName("navButton")

        # Seitenbereich
        self.pages = QStackedWidget()

        self.dashboard_page = DashboardPage()
        
        self.dashboard_page.set_parent_window(
            self
        )
        
        self.dashboard_window = (
            DashboardWindow(
                self.dashboard_page
            )
        )
        
        self.dashboard_page.set_detached_window(
            self.dashboard_window
        )
        
        self.session_page = SessionPage()
        self.refinery_page = RefineryPage()
        self.sales_page = SalesPage()

        # Wird vorerst als Verkaufsbereich genutzt
        self.salvage_page = SalvagePage()

        self.statistics_page = StatisticsPage()
        self.history_page = HistoryPage()

        self.pages.addWidget(
            QWidget()
        )

        self.pages.addWidget(
            self.session_page
        )
        
        self.pages.addWidget(self.refinery_page)
        self.pages.addWidget(self.sales_page)
        self.pages.addWidget(self.salvage_page)
        self.pages.addWidget(self.statistics_page)
        self.pages.addWidget(self.history_page)

        # Navigation verbinden
        
        self.btn_dashboard.clicked.connect(
            self.toggle_dashboard_window
        )

        self.btn_session.clicked.connect(
            lambda: self.switch_page(
                self.session_page,
                self.btn_session
            )
        )

        self.btn_refinery.clicked.connect(
            lambda: self.switch_page(
                self.refinery_page,
                self.btn_refinery
            )
        )

        self.btn_sales.clicked.connect(
            lambda: self.switch_page(
                self.sales_page,
                self.btn_sales
            )
        )

        self.btn_stats.clicked.connect(
            lambda: self.switch_page(
                self.statistics_page,
                self.btn_stats
            )
        )

        self.btn_history.clicked.connect(
            lambda: self.switch_page(
                self.history_page,
                self.btn_history
            )
        )

        # Navigation aufbauen
        
        
        nav_layout.addWidget(title)
        nav_layout.addSpacing(20)

        nav_layout.addWidget(self.btn_dashboard)
        nav_layout.addWidget(self.btn_session)
        nav_layout.addWidget(self.btn_refinery)
        nav_layout.addWidget(self.btn_sales)
        nav_layout.addWidget(self.btn_stats)
        nav_layout.addWidget(self.btn_history)

        version_label = QLabel(
            f"""
            <span style="color:#4D6B78;">
            {APP_NAME}<br>
            {APP_VERSION}<br>
            Build {APP_BUILD}
            </span>

            <br><br>

            <span style="color:#4D6B78;">
            Created by
            </span>

            <br>

            <span style="color:#C9A227;">
            Christian (Xangandu)
            </span>

            <br><br>

            <a href="changelog"
            style="color:#C9A227;">
            Changelog
            </a>
            """
        )

        version_label.setAlignment(
            Qt.AlignCenter
        )
        
        version_label.setTextFormat(
            Qt.RichText
        )

        version_label.setOpenExternalLinks(
            False
        )

        version_label.linkActivated.connect(
            self.show_changelog
        )

        version_label.setStyleSheet("""
        font-size: 11px;

        font-family: Rajdhani;
    """)

        nav_layout.addWidget(
            version_label
        )

        nav_layout.addStretch()

        # Layout zusammensetzen
        main_layout.addWidget(nav_widget, 1)
        main_layout.addWidget(self.pages, 5)

        self.set_active_button(
            self.btn_session
        )

        self.pages.setCurrentWidget(
            self.session_page
        )

    def switch_page(
        self,
        page,
        button
    ):

        if page == self.dashboard_page:
            self.dashboard_page.refresh_dashboard()

        if page == self.salvage_page:
            self.salvage_page.load_session()
            
        if page == self.sales_page:
            self.sales_page.load_sessions()
            
        if page == self.session_page:
            self.session_page.refresh_session()

        if page == self.refinery_page:
            self.refinery_page.load_sessions()
        
        if page == self.history_page:
            self.history_page.refresh_history()

        self.pages.setCurrentWidget(page)

        self.set_active_button(button)

    def set_active_button(
        self,
        active_button
    ):
        buttons = [
            self.btn_dashboard,
            self.btn_session,
            self.btn_refinery,
            self.btn_sales,
            self.btn_stats,
            self.btn_history,
        ]

        for button in buttons:

            button.setProperty(
                "active",
                False
            )

            button.style().unpolish(button)
            button.style().polish(button)

            button.update()

        active_button.setProperty(
            "active",
            True
        )

        active_button.style().unpolish(
            active_button
        )

        active_button.style().polish(
            active_button
        )
        active_button.update()

    def get_dashboard_page(self):

        return self.dashboard_page
    
    def is_dashboard_detached(self):

        return (
            self.dashboard_page
            .is_dashboard_detached()
        )
        
    def get_dashboard_mode(self):

        return (
            self.dashboard_page
            .get_dashboard_mode()
        )
        
    def has_detached_dashboard(self):

        return (
            self.dashboard_page
            .get_detached_window()
            is not None
        )
        
    def show_dashboard_window(self):

        if (
            self.dashboard_page
            .is_ready_for_detach()
        ):

            self.dashboard_page.mark_as_detached()

        self.dashboard_window.show_dashboard()

        self.btn_dashboard.setText(
            "Dashboard ●"
        )

    def hide_dashboard_window(self):

        if (
            self.dashboard_page
            .is_ready_for_attach()
        ):

            self.dashboard_page.mark_as_embedded()

        self.dashboard_window.hide_dashboard()

        self.btn_dashboard.setText(
            "Dashboard ⧉"
        )

    def toggle_dashboard_window(self):

        if (
            self.dashboard_page
            .is_detached()
        ):

            self.hide_dashboard_window()

        else:

            self.show_dashboard_window()
        
    def get_detached_dashboard(self):

        return (
            self.dashboard_page
            .get_detached_window()
        )

    def set_detached_dashboard(
        self,
        window
    ):

        self.dashboard_page.set_detached_window(
            window
        )

    def clear_detached_dashboard(self):

        self.dashboard_page.clear_detached_window()

    def show_changelog(self):

        dialog = ChangelogDialog()

        dialog.exec()