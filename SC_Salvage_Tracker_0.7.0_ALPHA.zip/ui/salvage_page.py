from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QVBoxLayout,
    QLineEdit,
    QPushButton,
    QFrame,
    QComboBox
)

from database.database import Database


class SalvagePage(QWidget):

    def __init__(self):
        super().__init__()

        self.db = Database()

        layout = QVBoxLayout()

        title = QLabel(
            "SALVAGE SALES"
        )

        title.setObjectName(
            "pageTitle"
        )

        layout.addWidget(title)

        panel = QFrame()

        panel.setMinimumHeight(
            320   
        )

        panel.setObjectName(
            "infoPanel"
        )

        panel_layout = QVBoxLayout()

        self.session_label = QLabel(
            "Aktive Session: Bitte Session starten"
        )

        self.crew_label = QLabel(
            "Crew: Bitte Crew anlegen"
        )

        panel_layout.addWidget(
            self.session_label
        )

        panel_layout.addWidget(
            self.crew_label
        )

        panel_layout.addSpacing(20)

        panel_layout.addWidget(
            QLabel("Verkaufswert")
        )

        self.sale_input = QLineEdit()
        self.sale_input.textChanged.connect(
            self.refresh_costs
        )

        self.sale_input.setPlaceholderText(
            "Bitte Verkaufswert eingeben"
        )

        panel_layout.addWidget(
            self.sale_input
        )

        self.share_label = QLabel(
            "Crew Anteil: 0 aUEC"
        )

        panel_layout.addWidget(
            self.share_label
        )

        self.costs_label = QLabel(
            "Gesamtkosten: 0 aUEC"
        )

        panel_layout.addWidget(
            self.costs_label
        )

        panel_layout.addSpacing(15)

        panel_layout.addWidget(
            QLabel("Kostenart")
        )

        self.cost_type = QComboBox()

        self.cost_type.addItems([
            "Mission",
            "Raffinerie"
        ])

        panel_layout.addWidget(
            self.cost_type
        )

        panel_layout.addWidget(
            QLabel("Betrag")
        )

        self.cost_amount = QLineEdit()

        self.cost_amount.setPlaceholderText(
            "Bitte Kostenbetrag eingeben"
        )

        panel_layout.addWidget(
            self.cost_amount
        )

        panel_layout.addWidget(
            QLabel("Wer hat die Kosten bezahlt?")
        )

        self.paid_by = QComboBox()

        panel_layout.addWidget(
            self.paid_by
        )

        self.cost_button = QPushButton(
            "Kosten hinzufügen"
        )

        self.cost_button.clicked.connect(
            self.add_cost
        )

        panel_layout.addWidget(
            self.cost_button
        )

        self.cost_list_label = QLabel(
            "Keine Kosten erfasst"
        )

        panel_layout.addWidget(
            self.cost_list_label
        )

        panel_layout.addSpacing(20)

        self.save_button = QPushButton(
            "Verkauf speichern"
        )
        
        self.save_button.clicked.connect(
        self.save_sale
        )

        self.save_button.setMinimumHeight(
            50
        )

        panel_layout.addWidget(
            self.save_button
        )

        panel.setLayout(
            panel_layout
        )

        layout.addWidget(panel)

        layout.addStretch()

        self.setLayout(layout)

        self.load_session()

    def load_session(self):

        session = self.db.get_active_session()

        if not session:

            self.session_label.setText(
                "Aktive Session: Bitte zuerst eine Session starten"
            )

            self.crew_label.setText(
                "Crew: Keine Crew vorhanden"
            )

            self.share_label.setText(
                "Crew Anteil: -"
            )

            self.costs_label.setText(
                "Gesamtkosten: -"
            )

            self.paid_by.clear()

            self.paid_by.addItem(
                "Bitte Spieler auswählen"
            )

            self.cost_list_label.setText(
                "Keine Kosten erfasst"
            )
            
            return

        session_id = session[0]
        ship_name = session[1]

        crew = self.db.get_crew_members(
            session_id
        )

        self.paid_by.clear()

        self.paid_by.addItem(
            "Bitte Spieler auswählen"
        )

        for member in crew:

            self.paid_by.addItem(
                member[0]
            )

        self.session_label.setText(
            f"Aktive Session: {ship_name}"
        )

        crew_names = "\n".join(
            member[0]
            for member in crew
        )

        self.crew_label.setText(
            f"Crew:\n{crew_names}"
        )

        self.refresh_costs()
        self.refresh_cost_list()

    def refresh_costs(self):

        session = self.db.get_active_session()

        if not session:
            return

        session_id = session[0]

        total_costs = self.db.get_total_costs(
            session_id
        )

        self.costs_label.setText(
            f"Gesamtkosten: "
            f"{total_costs:,.0f} aUEC"
        )

        try:

            sale_value = int(
                self.sale_input.text()
            )

        except ValueError:

            self.share_label.setText(
                "Crew Anteil: 0 aUEC"
            )

            return

        crew = self.db.get_crew_members(
            session_id
        )

        crew_count = len(crew)

        if crew_count == 0:
            return

        net_profit = (
            sale_value -
            total_costs
        )

        crew_share = int(
            net_profit / crew_count
        )

        self.share_label.setText(
            f"Crew Anteil: "
            f"{crew_share:,.0f} aUEC"
        )

    def refresh_cost_list(self):

        session = self.db.get_active_session()

        if not session:

            self.cost_list_label.setText(
                "Keine Kosten erfasst"
            )

            return

        costs = self.db.get_session_costs(
            session[0]
        )

        if not costs:

            self.cost_list_label.setText(
                "Keine Kosten erfasst"
            )

            return

        text = "ERFASSTE KOSTEN\n\n"

        for cost in costs:

            cost_type = cost[0]
            amount = cost[1]
            paid_by = cost[2]

            text += (
                f"{cost_type}: "
                f"{amount:,.0f} aUEC "
                f"({paid_by})\n"
            )

        self.cost_list_label.setText(
            text
        )

    def save_sale(self):

        session = self.db.get_active_session()

        if not session:
            return

        try:

            sale_value = int(
                self.sale_input.text()
            )

        except ValueError:
            return

        session_id = session[0]

        self.db.save_sale_value(
            session_id,
            sale_value
        )

        self.db.mark_session_sold(
            session_id
        )

        self.sale_input.clear()

        self.cost_type.setCurrentIndex(0)

        self.load_session()

    def add_cost(self):

        session = self.db.get_active_session()

        if not session:
            return
        
        if self.paid_by.currentIndex() == 0:
            return

        try:

            amount = int(
                self.cost_amount.text()
            )

        except ValueError:
            return

        self.db.add_cost(
            session[0],
            self.cost_type.currentText(),
            amount,
            self.paid_by.currentText()
        )

        self.cost_amount.clear()

        self.refresh_costs()
        self.refresh_cost_list()