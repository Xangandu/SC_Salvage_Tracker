from PySide6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout
)

from PySide6.QtCore import Qt


class DashboardWindow(QMainWindow):

    def __init__(
        self,
        dashboard_page
    ):
        super().__init__()

        self.dashboard_page = (
            dashboard_page
        )

        self.setWindowTitle(
            "MobiGlas Salvage Dashboard"
        )

        self.setObjectName(
            "dashboardWindow"
        )

        self.setMinimumSize(
            1400,
            800
        )

        self.resize(
            1800,
            1000
        )
        
        self.setWindowFlag(
            Qt.WindowStaysOnTopHint,
            False
        )

        central_widget = QWidget()

        self.setCentralWidget(
            central_widget
        )

        layout = QVBoxLayout()

        central_widget.setLayout(
            layout
        )

        layout.addWidget(
            self.dashboard_page
        )

        self.hide()

    def show_dashboard(self):

        self.dashboard_page.refresh_dashboard()

        self.dashboard_page.update()

        if self.isMinimized():

            self.showNormal()

        self.show()

        self.raise_()

        self.activateWindow()

    def hide_dashboard(self):

        self.dashboard_page.mark_as_embedded()

        self.hide()

    def toggle_visibility(self):

        if self.isVisible():

            self.hide_dashboard()

        else:

            self.show_dashboard()
            
    def set_always_on_top(
        self,
        enabled
    ):

        self.setWindowFlag(
            Qt.WindowStaysOnTopHint,
            enabled
        )

        self.show()
            
    def closeEvent(
        self,
        event
    ):

        self.dashboard_page.refresh_dashboard()

        self.dashboard_page.mark_as_embedded()

        parent_window = (
            self.dashboard_page
            .get_parent_window()
        )

        if parent_window:

            parent_window.btn_dashboard.setText(
                "Dashboard ⧉"
            )

        super().closeEvent(
            event
        )