from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QLabel,
    QTextEdit
)


class ChangelogDialog(QDialog):

    def __init__(self):

        super().__init__()

        self.setWindowTitle(
            "Changelog"
        )

        self.resize(
            900,
            600
        )
        
        self.setStyleSheet("""
        QDialog {
            background-color: #010B14;
        }

        QLabel {
            color: #00D8FF;
        }

        QTextEdit {
            background-color: #031A2B;
            color: white;

            border: 1px solid #00D8FF;
            border-radius: 10px;

            padding: 10px;

            font-size: 12pt;
        }
        """)

        layout = QVBoxLayout()

        title = QLabel(
            "SC Salvage Tracker Changelog"
        )
        
        title.setStyleSheet("""
        font-size: 28px;
        font-weight: bold;
        color: #00D8FF;
        """)

        title.setObjectName(
            "pageTitle"
        )

        changelog = QTextEdit()

        changelog.setReadOnly(
            True
        )

        changelog.setPlainText(
            """
        VERSION 0.6.0 Alpha
        Build 2025.10

        NEUE FUNKTIONEN
        ---------------
        • Dashboard zu globaler Übersicht erweitert
        • Globale Session-Anzahl
        • Globale aktive Sessions
        • Globale Verkaufsübersicht
        • Globale Raffinerieübersicht
        • Lifetime Materialstatistiken
        • Lifetime Umsatzanzeige
        • Lifetime Gewinnanzeige

        VERBESSERUNGEN
        --------------
        • Dashboard von Sessiondaten entkoppelt
        • Lifetime Materialwerte integriert
        • Session-Panel und globale Übersicht getrennt
        • Dashboard-Struktur für zukünftiges Zweitmonitor-Modul vorbereitet    
        
        VERSION 0.5.0 Alpha
        Build 2025.09

        NEUE FUNKTIONEN
        ---------------
        • Historie Modul hinzugefügt
        • Anzeige von SOLD Sessions
        • Anzeige von Session, Schiff und Status
        • Anzeige von RMC Materialmengen
        • Anzeige von CM Materialmengen
        • Gewinnanzeige pro Session
        • Automatische Aktualisierung der Historie beim Seitenwechsel

        VERBESSERUNGEN
        --------------
        • Historie vollständig im MobiGlas Design
        • Tabellenlayout optimiert
        • Historie lädt Daten direkt aus der Datenbank
        • Zeilennummern ausgeblendet

        VERSION 0.4.0 Alpha
        Build 2025.08

        NEUE FUNKTIONEN
        ---------------
        • Neue Verkaufsseite
        • Sessionauswahl für Verkäufe
        • RMC Verkauf
        • CM Verkauf
        • Gewinnberechnung
        • Missionskosten werden berücksichtigt
        • SOLD Workflow
        • Changelog System

        VERBESSERUNGEN
        --------------
        • Verkauf von reinem RMC möglich
        • Automatisches Entfernen verkaufter Sessions
        • Anzeige Reset bei leerer Verkaufsliste
        • Verkaufsliste filtert nur verkaufbare Sessions

        BUGFIXES
        --------
        • Refinery output_cm Speicherung korrigiert
        • Verkaufsseite aktualisiert sich beim Seitenwechsel
        • Anzeige nach letzter verkaufter Session korrigiert
        """
        )

        layout.addWidget(
            title
        )

        layout.addWidget(
            changelog
        )

        self.setLayout(
            layout
        )