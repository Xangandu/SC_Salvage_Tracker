from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QVBoxLayout,
    QHBoxLayout,
    QFrame
)
from database.database import Database
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Qt

class DashboardPage(QWidget):
    def __init__(self):
        super().__init__()

        self.db = Database()

        layout = QVBoxLayout()

        title = QLabel("SALVAGE DASHBOARD")
        self.dashboard_mode = "EMBEDDED"
        self.dashboard_detached = False
        self.parent_window = None
        title.setObjectName("pageTitle")

        # -------------------------
        # Dashboard Cards
        # -------------------------
        
        operation_title = self.create_section_title(
            "AKTUELLE OPERATION"
        )

        cards_layout = QHBoxLayout()

        cards_layout = QHBoxLayout()

        self.status_value = QLabel("IDLE")

        cards_layout.addWidget(
            self.create_card(
                "STATUS",
                self.status_value
            )
        )

        self.crew_value = QLabel("0")

        cards_layout.addWidget(
            self.create_card(
                "CREW",
                self.crew_value
            )
        )

        self.rmc_value = QLabel("0 SCU")

        cards_layout.addWidget(
            self.create_card(
                "RMC GESAMT",
                self.rmc_value
            )
        )

        self.cm_value = QLabel("0 SCU")

        cards_layout.addWidget(
            self.create_card(
                "CM GESAMT",
                self.cm_value
            )
        )
        
        materials_title = self.create_section_title(
            "MATERIALÜBERSICHT"
        )
        
        second_cards_layout = QHBoxLayout()
        
        operations_title = self.create_section_title(
            "EINSATZÜBERSICHT"
        )
        
        third_cards_layout = QHBoxLayout()
        
        finance_title = self.create_section_title(
            "FINANZEN"
        )
        
        fourth_cards_layout = QHBoxLayout()

        self.rubble_value = QLabel("0 SCU")

        second_cards_layout.addWidget(
            self.create_card(
                "RUBBLE GESAMT",
                self.rubble_value
            )
        )

        self.scraps_value = QLabel("0 SCU")

        second_cards_layout.addWidget(
            self.create_card(
                "SCRAPS GESAMT",
                self.scraps_value
            )
        )

        self.salvage_value = QLabel("0 SCU")

        second_cards_layout.addWidget(
            self.create_card(
                "SALVAGE GESAMT",
                self.salvage_value
            )
        )
        
        self.active_sessions_value = QLabel("0")

        third_cards_layout.addWidget(
            self.create_card(
                "AKTIV",
                self.active_sessions_value
            )
        )

        self.total_sessions_value = QLabel("0")

        third_cards_layout.addWidget(
            self.create_card(
                "SESSIONS",
                self.total_sessions_value
            )
        )

        self.sold_sessions_value = QLabel("0")

        third_cards_layout.addWidget(
            self.create_card(
                "VERKAUFT",
                self.sold_sessions_value
            )
        )

        self.ready_sessions_value = QLabel("0")

        third_cards_layout.addWidget(
            self.create_card(
                "VERKAUFSBEREIT",
                self.ready_sessions_value
            )
        )
        
        self.refinery_jobs_value = QLabel("0")

        second_cards_layout.addWidget(
            self.create_card(
                "RAFFINERIE",
                self.refinery_jobs_value
            )
        )
        
        self.total_sales_value = QLabel("0")

        fourth_cards_layout.addWidget(
            self.create_card(
                "UMSATZ",
                self.total_sales_value
            )
        )
        
        self.total_profit_value = QLabel("0")

        fourth_cards_layout.addWidget(
            self.create_card(
                "GEWINN",
                self.total_profit_value
            )
        )

        # -------------------------
        # Session Panel
        # -------------------------

        self.session_label = QLabel(
            "KEINE SESSION"
        )

        self.crew_info_label = QLabel(
            "0"
        )

        self.status_info_label = QLabel(
            "IDLE"
        )

        self.rmc_info_label = QLabel(
            "0 SCU"
        )

        self.cm_info_label = QLabel(
            "0 SCU"
        )

        self.refinery_info_label = QLabel(
            "0"
        )

        session_panel = QFrame()

        session_panel.setObjectName(
            "infoPanel"
        )

        session_layout = QVBoxLayout()

        session_title = QLabel(
            "AKTIVE SESSION"
        )

        session_title.setStyleSheet(
            """
            color: #00D9FF;

            font-family: Orbitron;

            font-size: 22px;

            font-weight: bold;
            """
        )

        session_layout.addWidget(
            session_title
        )

        session_layout.addSpacing(10)

        for label in [
            self.session_label,
            self.crew_info_label,
            self.status_info_label,
            self.rmc_info_label,
            self.cm_info_label,
            self.refinery_info_label
        ]:

            label.setStyleSheet(
                """
                color: white;

                font-size: 20px;

                font-weight: bold;
                """
            )

            session_layout.addWidget(
                label
            )

        session_layout.addStretch()

        session_panel.setLayout(
            session_layout
        )

        # -------------------------
        # Layout
        # -------------------------

        layout.addWidget(title)

        layout.addWidget(
            operation_title
        )

        layout.addLayout(cards_layout)

        layout.addSpacing(10)

        layout.addWidget(
            materials_title
        )

        layout.addLayout(
            second_cards_layout
        )

        layout.addSpacing(10)

        layout.addWidget(
            operations_title
        )

        layout.addLayout(
            third_cards_layout
        )

        layout.addSpacing(10)

        layout.addWidget(
            finance_title
        )

        layout.addLayout(
            fourth_cards_layout
        )

        layout.addSpacing(20)

        layout.addWidget(session_panel)

        layout.addStretch()

        self.setLayout(layout)

        self.refresh_dashboard()
        
    def detach_dashboard(self):

        self.dashboard_mode = "DETACHED"

        self.dashboard_detached = True
        
    def attach_dashboard(self):

        self.dashboard_mode = "EMBEDDED"

        self.dashboard_detached = False
        
    def is_dashboard_detached(self):

        return self.dashboard_detached
    
    def set_parent_window(
        self,
        parent_window
    ):

        self.parent_window = parent_window
        
    def get_parent_window(self):

        return self.parent_window
    
    def can_detach(self):

        return (
            self.parent_window
            is not None
        )
        
    def can_attach(self):

        return self.is_detached

    def get_dashboard_mode(self):

        return self.dashboard_mode

    def has_parent_window(self):

        return (
            self.parent_window
            is not None
        )

    def get_detached_window(self):

        return self.detached_window
    
    def set_detached_window(
        self,
        window
    ):

        self.detached_window = window
        
    def clear_detached_window(self):

        self.detached_window = None
        
    def has_detached_window(self):

        return (
            self.detached_window
            is not None
        )

    def mark_as_detached(self):

        self.detach_dashboard()

    def mark_as_embedded(self):

        self.attach_dashboard()
        
    def is_embedded(self):

        return (
            self.dashboard_mode
            == "EMBEDDED"
        )

    def is_detached(self):

        return (
            self.dashboard_mode
            == "DETACHED"
        )
        
    def toggle_dashboard_mode(self):

        if self.is_detached():

            self.attach_dashboard()

        else:

            self.detach_dashboard()
            
    def reset_dashboard_mode(self):

        self.dashboard_mode = "EMBEDDED"

        self.dashboard_detached = False
        
    def has_valid_parent(self):

        return (
            self.parent_window
            is not None
        )
        
    def has_valid_dashboard_window(self):

        return (
            self.detached_window
            is not None
        )
        
    def can_toggle_dashboard(self):

        return (
            self.has_valid_parent()
        )
        
    def is_ready_for_detach(self):

        return (
            self.has_valid_parent()
            and not self.is_detached()
        )

    def is_ready_for_attach(self):

        return (
            self.has_valid_dashboard_window()
            and self.is_detached()
        )

    def get_dashboard_state(self):

        return {
            "mode": self.dashboard_mode,
            "detached": self.is_detached(),
            "has_parent": self.has_valid_parent(),
            "has_window": (
                self.has_valid_dashboard_window()
            )
        }

    def reset_window_references(self):

        self.detached_window = None

        self.parent_window = None

    def create_section_title(
        self,
        text
    ):

        label = QLabel(text)

        label.setStyleSheet(
            """
            color: #00D9FF;

            font-family: Orbitron;

            font-size: 18px;

            font-weight: bold;

            letter-spacing: 3px;

            padding-top: 10px;

            padding-bottom: 4px;
            """
        )

        return label

    def create_card(
        self,
        title,
        value
    ):
        card = QFrame()
        card.setMinimumHeight(140)
        card.setMaximumHeight(160)

        card.setObjectName(
            "infoPanel"
        )

        layout = QVBoxLayout()

        title_label = QLabel(title)

        title_label.setStyleSheet(
            """
            color: #00D9FF;

            font-family: Orbitron;

            font-size: 22px;

            font-weight: bold;

            letter-spacing: 2px;
            """
        )

        if isinstance(value, QLabel):
            value_label = value
        else:
            value_label = QLabel(value)

        value_label.setStyleSheet(
            """
            font-size: 26px;
            font-weight: bold;
            color: #FFFFFF;
            """
        )

        layout.addWidget(title_label)

        hud_layout = QHBoxLayout()

        left_line = QFrame()
        left_line.setFrameShape(QFrame.HLine)
        left_line.setStyleSheet(
            "color: #00D9FF;"
        )

        center_box = QLabel("▪")
        center_box.setStyleSheet(
            """
            color: #55E8FF;
            font-size: 18px;
            font-weight: bold;
            """
        )
        center_box.setAlignment(
            Qt.AlignCenter
        )

        right_line = QFrame()
        right_line.setFrameShape(QFrame.HLine)
        right_line.setStyleSheet(
            "color: #00D9FF;"
        )

        hud_layout.addWidget(left_line)
        hud_layout.addWidget(center_box)
        hud_layout.addWidget(right_line)

        layout.addLayout(hud_layout)

        layout.addSpacing(10)

        layout.addWidget(value_label)

        layout.addStretch()

        card.setLayout(layout)

        return card
    
    def refresh_dashboard(self):
        
        print("REFRESH_DASHBOARD WIRD AUSGEFÜHRT")

        session = self.db.get_latest_session()

        if not session:

            self.status_value.setText("IDLE")
            self.crew_value.setText("0")
            self.rmc_value.setText("0 SCU")
            self.cm_value.setText("0 SCU")
            self.rubble_value.setText(
                "0 SCU"
            )

            self.scraps_value.setText(
                "0 SCU"
            )

            self.salvage_value.setText(
                "0 SCU"
            )

            self.session_label.setText(
                "KEINE SESSION"
            )

            self.crew_info_label.setText(
                "Crew: 0"
            )

            self.status_info_label.setText(
                "Status: IDLE"
            )

            self.rmc_info_label.setText(
                "RMC: 0 SCU"
            )

            self.cm_info_label.setText(
                "CM: 0 SCU"
            )

            self.refinery_info_label.setText(
                "Offene Raffinerieaufträge: 0"
            )
            
            self.sold_sessions_value.setText("0")
            self.ready_sessions_value.setText("0")
            self.refinery_jobs_value.setText("0")
            self.total_sales_value.setText("0 aUEC")
            self.total_profit_value.setText("0 aUEC")
            self.active_sessions_value.setText("0")
            self.total_sessions_value.setText("0")

            return

        session_id = session[0]
        ship_name = session[1]
        status = session[2]
        
        status_text = {
            "ACTIVE": "AKTIV",
            "WAITING_FOR_REFINERY": "WARTET AUF RAFFINERIE",
            "REFINERY_COMPLETED": "VERKAUFSBEREIT",
            "SOLD": "VERKAUFT"
        }.get(
            status,
            status
        )

        rmc = self.db.get_global_material_total(
            "RMC"
        )

        cm = self.db.get_global_material_total(
            "CM"
        )
        
        print(
            "DASHBOARD CM:",
            cm
        )
        
        lifetime_rubble = (
            self.db.get_global_material_total(
                "CM_RUBBLE"
            )
        )

        lifetime_scraps = (
            self.db.get_global_material_total(
                "CM_SCRAPS"
            )
        )

        lifetime_salvage = (
            self.db.get_global_material_total(
                "CM_SALVAGE"
            )
        )
        
        session_rmc = self.db.get_material_total(
            session_id,
            "RMC"
        )

        session_cm = self.db.get_total_cm(
            session_id
        )

        crew = self.db.get_crew_members(
            session_id
        )
        
        open_refinery_jobs = (
            self.db.get_open_refinery_jobs()
        )
        
        sold_sessions = (
            self.db.get_sold_session_count()
        )
        
        active_sessions = (
            self.db.get_active_session_count()
        )
        
        total_sessions = (
            self.db.get_total_session_count()
        )
        
        ready_sessions = (
            self.db.get_ready_for_sale_count()
        )
        
        total_sales = (
            self.db.get_total_sales_value()
        )
        
        total_profit = (
            self.db.get_total_profit()
        )
        
        active_sessions = (
            self.db.get_active_session_count()
        )
        
        self.status_value.setText(
            status_text
        )

        self.crew_value.setText(
            str(len(crew))
        )

        self.rmc_value.setText(
            f"{rmc:,.0f} SCU"
        )

        self.cm_value.setText(
            f"{cm:,.0f} SCU"
        )
        
        self.rubble_value.setText(
            f"{lifetime_rubble:,.0f} SCU"
        )

        self.scraps_value.setText(
            f"{lifetime_scraps:,.0f} SCU"
        )

        self.salvage_value.setText(
            f"{lifetime_salvage:,.0f} SCU"
        )
        
        self.sold_sessions_value.setText(
            str(sold_sessions)
        )
        
        self.active_sessions_value.setText(
            str(active_sessions)
        )
        
        self.total_sessions_value.setText(
            str(total_sessions)
        )
        
        self.ready_sessions_value.setText(
            str(ready_sessions)
        )
        
        self.refinery_jobs_value.setText(
            str(open_refinery_jobs)
        )
        
        self.total_sales_value.setText(
            f"{total_sales:,.0f} aUEC"
        )
        
        self.total_profit_value.setText(
            f"{total_profit:,.0f} aUEC"
        )
        
        self.session_label.setText(
            ship_name
        )

        self.crew_info_label.setText(
            f"Crew: {len(crew)}"
        )

        self.status_info_label.setText(
            f"Status: {status_text}"
        )

        self.rmc_info_label.setText(
            f"RMC: {session_rmc:.1f} SCU"
        )

        self.cm_info_label.setText(
            f"CM: {session_cm:.1f} SCU"
        )

        self.refinery_info_label.setText(
            f"Offene Raffinerieaufträge: {open_refinery_jobs}"
        )