from PySide6.QtWidgets import QWidget, QLabel, QVBoxLayout


class StatisticsPage(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        title = QLabel("STATISTIK")
        title.setObjectName("pageTitle")

        layout.addWidget(title)
        layout.addStretch()

        self.setLayout(layout)