from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QTableWidget,
    QTableWidgetItem
)

from database.database import Database


class HistoryPage(QWidget):

    def __init__(self):

        super().__init__()

        main_layout = QVBoxLayout()

        title = QLabel(
            "HISTORIE"
        )

        title.setObjectName(
            "pageTitle"
        )

        self.history_table = QTableWidget()

        self.history_table.horizontalHeader().setStretchLastSection(
            True
        )

        self.history_table.setObjectName(
            "historyTable"
        )
        
        self.history_table.verticalHeader().setVisible(
            False
        )

        self.history_table.setColumnCount(
            6
        )

        self.history_table.setHorizontalHeaderLabels([
            "Session",
            "Schiff",
            "Status",
            "RMC",
            "CM",
            "Gewinn"
        ])
        
        self.history_table.setColumnWidth(
            0, 90
        )

        self.history_table.setColumnWidth(
            1, 180
        )

        self.history_table.setColumnWidth(
            2, 120
        )

        self.history_table.setColumnWidth(
            3, 100
        )

        self.history_table.setColumnWidth(
            4, 100
        )

        main_layout.addWidget(
            title
        )

        main_layout.addWidget(
            self.history_table
        )

        self.setLayout(
            main_layout
        )

        self.load_history()
        
    def refresh_history(self):

        self.load_history()    

    def load_history(self):

        db = Database()

        sessions = db.get_sold_sessions()

        self.history_table.setRowCount(
            len(sessions)
        )

        for row, session in enumerate(
            sessions
        ):

            session_id = session[0]
            ship = session[1]
            status = session[2]

            self.history_table.setItem(
                row,
                0,
                QTableWidgetItem(
                    f"#{session_id}"
                )
            )
            
            rmc = db.get_material_total(
                session_id,
                "RMC"
            )

            cm = db.get_material_total(
                session_id,
                "CM"
            )

            profit = db.get_net_profit(
                session_id
            )

            self.history_table.setItem(
                row,
                1,
                QTableWidgetItem(
                    ship
                )
            )

            self.history_table.setItem(
                row,
                2,
                QTableWidgetItem(
                    status
                )
            )
            
            self.history_table.setItem(
                row,
                3,
                QTableWidgetItem(
                    f"{rmc:,.0f}"
                )
            )

            self.history_table.setItem(
                row,
                4,
                QTableWidgetItem(
                    f"{cm:,.0f}"
                )
            )

            self.history_table.setItem(
                row,
                5,
                QTableWidgetItem(
                    f"{profit:,.0f}"
                )
            )