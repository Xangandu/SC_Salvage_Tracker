from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QVBoxLayout,
    QHBoxLayout,
    QFrame,
    QComboBox,
    QLineEdit,
    QPushButton,
    QInputDialog
    
)

from PySide6.QtGui import (
    QPixmap
)

from datetime import datetime, timedelta

from database.database import Database


class RefineryPage(QWidget):

    def __init__(self):
        super().__init__()

        self.db = Database()
    
        layout = QVBoxLayout()

        title = QLabel(
            "REFINERY"
        )

        title.setObjectName(
            "pageTitle"
        )

        layout.addWidget(title)

        panel = QFrame()

        panel.setObjectName(
            "infoPanel"
        )
   
        active_label = QLabel(
            "AKTIVE AUFTRÄGE"
        
        )
        active_label.setObjectName(
            "sectionTitle"
        )

        active_label.setObjectName(
            "sectionTitle"
        )
        panel_layout = QVBoxLayout()    
        panel_layout.addWidget(
            active_label
        )

        self.jobs_container = QVBoxLayout()

        panel_layout.addLayout(
            self.jobs_container
        )

        panel_layout.addSpacing(20)

        create_label = QLabel(
            "AUFTRAG ANLEGEN"
        )
        
        create_label.setObjectName(
            "subSectionTitle"
        )

        panel_layout.addWidget(
            create_label
        )

        panel_layout.addWidget(
            QLabel("Session")
        )

        self.session_combo = QComboBox()
        
        self.session_combo.currentIndexChanged.connect(
            self.load_jobs
        )

        panel_layout.addWidget(
            self.session_combo
        )

        panel_layout.addWidget(
            QLabel("Material")
        )

        self.material_combo = QComboBox()

        self.material_combo.addItems([
            "CM-Rubble",
            "CM-Scraps",
            "CM-Salvage"
        ])

        panel_layout.addWidget(
            self.material_combo
        )

        panel_layout.addWidget(
            QLabel("Input SCU")
        )

        self.input_scu = QLineEdit()

        panel_layout.addWidget(
            self.input_scu
        )

        panel_layout.addWidget(
            QLabel("Stunden")
        )

        self.hours_input = QLineEdit()

        self.hours_input.setPlaceholderText(
            "z.B. 28"
        )

        panel_layout.addWidget(
            self.hours_input
        )

        panel_layout.addWidget(
            QLabel("Minuten")
        )

        self.minutes_input = QLineEdit()

        self.minutes_input.setPlaceholderText(
            "z.B. 35"
        )

        panel_layout.addWidget(
            self.minutes_input
        )

        self.hours_input.textChanged.connect(
            self.update_ready_time
        )

        self.minutes_input.textChanged.connect(
            self.update_ready_time
        )

        self.ready_info_label = QLabel(
            "● RAFFINERIE STATUS\n\n"
            "Fertig am:\n"
            "-\n\n"
            "Verbleibend:\n"
            "-\n\n"
            "Status:\n"
            "WARTET AUF EINGABE"
        )

        self.ready_info_label.setObjectName(
            "refineryStatusPanel"
        )

        panel_layout.addWidget(
            self.ready_info_label
        )

        self.create_button = QPushButton(
            "Auftrag erstellen"
        )

        self.create_button.clicked.connect(
            self.create_job
        )

        panel_layout.addWidget(
            self.create_button
        )

        panel.setLayout(
            panel_layout
        )

        layout.addWidget(
            panel
        )

        layout.addStretch()

        self.setLayout(
            layout
        )

        self.load_sessions()

    def update_ready_time(self):

        try:

            hours = int(
                self.hours_input.text() or 0
            )

            minutes = int(
                self.minutes_input.text() or 0
            )

        except ValueError:

            self.ready_info_label.setText(
                "● RAFFINERIE STATUS\n\n"
                "Fertig am:\n-\n\n"
                "Verbleibend:\n-\n\n"
                "Status:\nWARTET AUF EINGABE"
            )

            return

        ready_time = (
            datetime.now()
            + timedelta(
                hours=hours,
                minutes=minutes
            )
        )

        self.ready_info_label.setText(
            f"● RAFFINERIE STATUS\n\n"
            f"Fertig am:\n"
            f"{ready_time.strftime('%d.%m.%Y %H:%M')}\n\n"
            f"Verbleibend:\n"
            f"{hours}h {minutes}m\n\n"
            f"Status:\n"
            f"IN BEARBEITUNG"
        )
    def load_jobs(self):

        session_id = (
            self.session_combo.currentData()
        )

        if not session_id:
            return

        jobs = self.db.get_refinery_jobs(
            session_id
        )
        
        while self.jobs_container.count():

            item = self.jobs_container.takeAt(0)

            if item.widget():
                item.widget().deleteLater()

        if not jobs:

            info_widget = QWidget()

            info_widget.setObjectName(
                "emptyInfoPanel"
            )

            info_layout = QHBoxLayout()

            icon_label = QLabel()

            icon_label.setPixmap(
                QPixmap(
                    "assets/images/icons/info.svg"
                ).scaled(
                    32,
                    32
                )
            )

            icon_label.setFixedSize(
                32,
                32
            )

            text_label = QLabel(
                "Für diese Session wurden noch keine Raffinerie-Aufträge erstellt."
            )

            text_label.setObjectName(
                "emptyInfo"
            )

            info_layout.addWidget(
                icon_label
            )
            
            info_layout.setSpacing(
                8
            )

            info_layout.addWidget(
                text_label
            )

            info_layout.addStretch()

            info_widget.setLayout(
                info_layout
            )

            self.jobs_container.addWidget(
                info_widget
            )

            return

        for job in jobs:

            job_id = job[0]

            material = job[1]
            input_scu = job[2]
            
            ship = job[7]
            session_start = job[8]

            session_date = datetime.strptime(
                session_start,
                "%Y-%m-%d %H:%M:%S"
            ).strftime(
                "%d.%m.%Y"
            )

            ready_time = datetime.strptime(
                job[6],
                "%Y-%m-%d %H:%M:%S"
            )

            remaining = (
                ready_time
                - datetime.now()
            )

            remaining_minutes = int(
                remaining.total_seconds() / 60
            )
            
            print(
                "READY:",
                ready_time
            )

            print(
                "NOW:",
                datetime.now()
            )

            print(
                "REMAINING MINUTES:",
                remaining_minutes
            )

            if remaining_minutes <= 0:

                is_ready = True

                status_text = "ABHOLBEREIT"

                status_icon = (
                    "assets/images/icons/ready.svg"
                )

                remaining_text = "Fertig"

            elif remaining_minutes <= 60:
                
                is_ready = False

                status_text = "ENDPHASE"

                status_icon = (
                    "assets/images/icons/processing.svg"
                )

                remaining_text = (
                    f"{remaining_minutes} Min"
                )

            else:
                
                is_ready = False

                hours = (
                    remaining_minutes // 60
                )

                minutes = (
                    remaining_minutes % 60
                )

                status_text = (
                    "IN BEARBEITUNG"
                )

                status_icon = (
                    "assets/images/icons/processing.svg"
                )

                remaining_text = (
                    f"{hours}h {minutes}m"
                )

            ready_text = ready_time.strftime(
                "%d.%m.%Y %H:%M"
            )
            
            card = QFrame()

            card.setObjectName(
                "jobCard"
            )

            card_layout = QVBoxLayout()
            
            header_widget = QWidget()

            header_layout = QHBoxLayout()
            header_layout.setSpacing(
                10
            )

            header_layout.setContentsMargins(
                0,
                0,
                0,
                0
            )

            icon_label = QLabel()

            icon_label.setPixmap(
                QPixmap(
                    status_icon
                ).scaled(
                    32,
                    32
                )
            )

            status_label = QLabel(
                status_text
            )
            
            status_label.setObjectName(
                "jobStatusLabel"
            )

            header_layout.addWidget(
                icon_label
            )

            header_layout.addWidget(
                status_label
            )

            header_layout.addStretch()

            header_widget.setLayout(
                header_layout
            )

            card_layout.addWidget(
                header_widget
            )

            card_layout.addWidget(
                QLabel(
                    f"{session_date} | {ship}"
                )
            )

            card_layout.addWidget(
                QLabel(material)
            )

            card_layout.addWidget(
                QLabel(
                    f"Input: {input_scu:.0f} SCU"
                )
            )

            card_layout.addWidget(
                QLabel(
                    f"Fertig: {ready_text}"
                )
            )

            card_layout.addWidget(
                QLabel(
                    f"Verbleibend: {remaining_text}"
                )
            )
            
            if is_ready:

                collect_button = QPushButton(
                    "ABHOLEN"
                )
                
                collect_button.clicked.connect(
                    lambda checked=False, id=job_id:
                    self.collect_job(id)
                )

                card_layout.addWidget(
                    collect_button
                )
            
            card.setLayout(
                card_layout
            )

            self.jobs_container.addWidget(
                card
            )

            print(
                "CARD ADDED:",
                self.jobs_container.count()
            )
        
    def load_sessions(self):

        self.session_combo.clear()

        self.session_combo.addItem(
            "Bitte Session auswählen"
        )

        self.db.cursor.execute("""
        SELECT
            id,
            ship,
            start_time
        FROM sessions
        WHERE status = 'WAITING_FOR_REFINERY'
        ORDER BY id DESC
        """)

        sessions = self.db.cursor.fetchall()

        for session in sessions:

            session_id = session[0]
            ship = session[1]
            start_time = session[2]

            date_text = datetime.strptime(
                start_time,
                "%Y-%m-%d %H:%M:%S"
            ).strftime(
                "%d.%m.%Y"
            )

            total_scu = self.db.get_session_total_scu(session_id)

            self.session_combo.addItem(
                f"#{session_id} | {date_text} | {ship}",
                session_id
            )
            
        self.load_jobs()
            
    def create_job(self):

        session_id = self.session_combo.currentData()

        if not session_id:
            return

        material_type = (
            self.material_combo.currentText()
        )

        try:

            input_scu = float(
                self.input_scu.text()
            )

            hours = int(
                self.hours_input.text() or 0
            )

            minutes = int(
                self.minutes_input.text() or 0
            )

        except ValueError:

            self.jobs_label.setText(
                "Ungültige Werte"
            )

            return

        ready_time = (
            datetime.now()
            + timedelta(
                hours=hours,
                minutes=minutes
            )
        )

        self.db.add_refinery_job(
            session_id,
            material_type,
            input_scu,
            ready_time.strftime(
                "%Y-%m-%d %H:%M:%S"
            )
        )

        self.input_scu.clear()

        self.hours_input.clear()

        self.minutes_input.clear()

        self.ready_info_label.setText(
            "● RAFFINERIE STATUS\n\n"
            "Fertig am:\n-\n\n"
            "Verbleibend:\n-\n\n"
            "Status:\nWARTET AUF EINGABE"
        )

        self.load_jobs()
        
        main_window = self.window()

        if hasattr(
            main_window,
            "dashboard_page"
        ):

            main_window.dashboard_page.refresh_dashboard()
        
    def collect_job(
        self,
        job_id
    ):

        output_cm, ok = QInputDialog.getDouble(
            self,
            "Raffinerie-Abholung",
            "Tatsächliche CM-Menge:",
            0,
            0,
            100000,
            1
        )

        if not ok:
            return

        self.db.cursor.execute("""
        SELECT
            session_id,
            material_type
        FROM refinery_jobs
        WHERE id = ?
        """, (job_id,))

        job = self.db.cursor.fetchone()
        session_id = job[0]
        print(
            "REFINERY SESSION:",
            session_id
        )
        material_type = job[1]
        
        print(
            "CM WIRD ERZEUGT:",
            output_cm
        )

        self.db.add_material(
            session_id,
            "CM",
            output_cm
        )

        self.db.cursor.execute("""
        UPDATE refinery_jobs
        SET output_cm = ?
        WHERE id = ?
        """, (
            output_cm,
            job_id
        ))

        self.db.connection.commit()

        self.db.collect_refinery_job(
            job_id
        )

        self.load_jobs()

        main_window = self.window()

        if hasattr(
            main_window,
            "dashboard_page"
        ):

            main_window.dashboard_page.refresh_dashboard()