import sys
from PySide6.QtWidgets import QApplication
from ui.main_window import MainWindow
from config.version import (
    APP_NAME,
    APP_VERSION
)

from PySide6.QtGui import QFontDatabase
app = QApplication(sys.argv)

QFontDatabase.addApplicationFont(
    "assets/fonts/Orbitron-Bold.ttf"
)

QFontDatabase.addApplicationFont(
    "assets/fonts/Rajdhani-Regular.ttf"
)

QFontDatabase.addApplicationFont(
    "assets/fonts/Rajdhani-Bold.ttf"
)

with open("assets/styles/mobiglas.qss", "r", encoding="utf-8") as file:
    app.setStyleSheet(file.read())

window = MainWindow()
window.show()

sys.exit(app.exec())