
# SC Salvage Tracker – Projektanalyse
Stand: Analyse der hochgeladenen Version 0.3.0 Alpha

## Technik
- Python 3.14
- PySide6
- SQLite
- MobiGlas UI Design

## Projektstruktur

SCCommandCenter_MobiGlas
├── main.py
├── config/
│   └── version.py
├── database/
│   ├── __init__.py
│   └── database.py
├── data/
│   ├── salvage_tracker.db
│   └── ships.json
├── assets/
│   ├── fonts/
│   ├── images/
│   └── styles/
└── ui/
    ├── main_window.py
    ├── dashboard_page.py
    ├── session_page.py
    ├── salvage_page.py
    ├── run_completion_page.py
    ├── crew_page.py
    ├── history_page.py
    └── statistics_page.py

## Datenbank

### Tabelle sessions
- id
- ship
- start_time
- end_time
- status
- rmc_scu
- cms_scu
- sale_value
- created_at

### Tabelle crew_members
- id
- session_id
- player_name

### Tabelle costs
- id
- session_id
- cost_type
- amount
- paid_by

## Bereits vorhanden

### Session-System
- Session erstellen
- Schiff speichern
- Crew speichern
- Aktive Session abrufen

### Salvage-System
- RMC speichern
- CMS speichern
- Session abschließen
- Status WAITING_FOR_SALE

### Verkaufssystem
- Verkaufserlös speichern
- Status SOLD

### Kostenverwaltung
- Mission
- Raffinerie
- Kostenverursacher

### Dashboard
- Aktive Session
- Crew
- RMC
- CMS

## Aktuelle Architektur

ACTIVE
↓
WAITING_FOR_SALE
↓
SOLD

## Offene Punkte

### Hoch
1. Gewinnberechnung
2. Crew-Anteile
3. Kostenrückerstattung
4. Run Completion fertigstellen

### Mittel
5. Historie vervollständigen
6. Statistikseite ausbauen
7. Crew-Verwaltung integrieren

### Niedrig
8. Exportfunktion
9. Backupfunktion
10. Mehrere aktive Runs

## Empfehlung für Version 0.3.1 Alpha

1. Netto Gewinn berechnen
2. Crew-Anteil berechnen
3. Kostenrückerstattung pro Spieler
4. Auszahlungsübersicht
5. Run Completion Page nutzen

## Ziel für Version 0.4.0

Vollständiger Salvage Run Ablauf:

Session
→ Salvage
→ Verkauf
→ Gewinnberechnung
→ Auszahlung
→ Historie
→ Statistik
