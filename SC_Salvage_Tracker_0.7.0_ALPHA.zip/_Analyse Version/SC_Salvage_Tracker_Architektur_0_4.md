# SC Salvage Tracker
## Architektur 0.4 (Entwurf)

Version 0.4 Architekturentwurf

## Ziel
Der SC Salvage Tracker soll den vollständigen Material- und Geldfluss eines Salvage-Unternehmens abbilden.

## Zielgruppen
- Solo-Spieler
- Kleine Crews
- Große Organisationen

## Grundprinzip
Eine Session erzeugt Rohstoffe.
Eine Session erzeugt kein Geld.
Geld entsteht erst durch Verkäufe.

## Materialsystem
- RMC
- CM-Rubble
- CM-Scraps
- CM-Salvage
- CM

## Session
Enthält:
- Schiff
- Crew
- Kosten
- Erzeugte Materialien

Status:
- ACTIVE
- COMPLETED

## Datenbank 0.4 (geplant)
- sessions
- crew_members
- costs
- session_materials
- refinery_jobs
- sales
- sale_items

## Leitsatz
Der Tracker ist kein Run-Tracker.
Der Tracker ist ein Material-, Verkaufs- und Gewinn-Management-System für Star Citizen.
