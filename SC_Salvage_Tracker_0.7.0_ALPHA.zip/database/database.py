import sqlite3
from pathlib import Path


class Database:

    def __init__(self):
        db_path = Path("data/salvage_tracker.db")

        db_path.parent.mkdir(exist_ok=True)

        self.connection = sqlite3.connect(db_path)
        
        print(
            "DB DATEI:",
            self.connection.execute(
                "PRAGMA database_list"
            ).fetchall()
        )
        
        self.cursor = self.connection.cursor()
        
        self.connection.commit()

        self.create_tables()

    def create_tables(self):

        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS sessions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            ship TEXT NOT NULL,

            start_time TEXT,
            end_time TEXT,

            status TEXT DEFAULT 'ACTIVE',

            rmc_scu REAL DEFAULT 0,
            cms_scu REAL DEFAULT 0,

            sale_value INTEGER DEFAULT 0,

            created_at TEXT
        )
        """)

        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS session_materials(
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            session_id INTEGER,

            material_type TEXT,

            amount REAL,

            FOREIGN KEY(session_id)
            REFERENCES sessions(id)
        )
        """)

        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS crew_members(
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            session_id INTEGER,

            player_name TEXT,

            FOREIGN KEY(session_id)
            REFERENCES sessions(id)
        )
        """)

        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS costs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            session_id INTEGER,

            cost_type TEXT,
            amount INTEGER,

            paid_by TEXT,

            FOREIGN KEY(session_id)
            REFERENCES sessions(id)
        )
        """)
        
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS refinery_jobs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            session_id INTEGER,

            material_type TEXT,

            input_scu REAL,

            output_cm REAL DEFAULT 0,

            status TEXT DEFAULT 'PROCESSING',

            created_at TEXT,

            ready_time TEXT,

            FOREIGN KEY(session_id)
            REFERENCES sessions(id)
        )
        """)

        self.connection.commit()

    def create_session(
        self,
        ship,
        start_time
    ):

        self.cursor.execute("""
        UPDATE sessions
        SET status = 'WAITING_FOR_REFINERY'
        WHERE status = 'ACTIVE'
        """)
        
        self.cursor.execute("""
        INSERT INTO sessions(
            ship,
            start_time
        )
        VALUES(?,?)
        """, (
            ship,
            start_time
        ))

        self.connection.commit()

        return self.cursor.lastrowid

    def add_crew_member(
        self,
        session_id,
        player_name
    ):

        self.cursor.execute("""
        INSERT INTO crew_members(
            session_id,
            player_name
        )
        VALUES(?,?)
        """, (
            session_id,
            player_name
        ))

        self.connection.commit()

    def get_active_session(self):

        self.cursor.execute("""
        SELECT
            id,
            ship,
            status
        FROM sessions
        WHERE status = 'ACTIVE'
        ORDER BY id DESC
        LIMIT 1
        """)

        return self.cursor.fetchone()
    
    def get_latest_session(self):

        self.cursor.execute("""
        SELECT
            id,
            ship,
            status
        FROM sessions
        ORDER BY id DESC
        LIMIT 1
        """)

        return self.cursor.fetchone()

    def get_open_refinery_jobs(self):

        self.cursor.execute("""
        SELECT COUNT(*)
        FROM refinery_jobs
        WHERE status != 'COLLECTED'
        """)

        return self.cursor.fetchone()[0]
    
    def get_crew_members(self, session_id):

        self.cursor.execute("""
        SELECT player_name
        FROM crew_members
        WHERE session_id = ?
        """, (session_id,))

        return self.cursor.fetchall()
    
    def add_cost(
        self,
        session_id,
        cost_type,
        amount,
        paid_by
    ):

        self.cursor.execute("""
        INSERT INTO costs(
            session_id,
            cost_type,
            amount,
            paid_by
        )
        VALUES(?,?,?,?)
        """, (
            session_id,
            cost_type,
            amount,
            paid_by
        ))

        self.connection.commit()

    def end_session(
        self,
        session_id
    ):

        self.cursor.execute("""
        UPDATE sessions
        SET
            status = 'WAITING_FOR_REFINERY',
            end_time = CURRENT_TIMESTAMP
        WHERE id = ?
        """, (session_id,))

        self.connection.commit()

    def get_session_costs(
        self,
        session_id
    ):

        self.cursor.execute("""
        SELECT
            cost_type,
            amount,
            paid_by
        FROM costs
        WHERE session_id = ?
        """, (session_id,))

        return self.cursor.fetchall()
    
    def get_total_costs(
        self,
        session_id
    ):

        self.cursor.execute("""
        SELECT COALESCE(
            SUM(amount),
            0
        )
        FROM costs
        WHERE session_id = ?
        """, (session_id,))

        return self.cursor.fetchone()[0]


    def get_sale_value(
        self,
        session_id
    ):

        self.cursor.execute("""
        SELECT sale_value
        FROM sessions
        WHERE id = ?
        """, (session_id,))

        result = self.cursor.fetchone()

        if result:
            return result[0]

        return 0


    def get_net_profit(
        self,
        session_id
    ):

        sale_value = self.get_sale_value(
            session_id
        )

        total_costs = self.get_total_costs(
            session_id
        )

        return sale_value - total_costs


    def get_cost_refunds(
        self,
        session_id
    ):

        self.cursor.execute("""
        SELECT
            paid_by,
            SUM(amount)
        FROM costs
        WHERE session_id = ?
        GROUP BY paid_by
        """, (session_id,))

        return self.cursor.fetchall()
    
    def get_crew_share(
        self,
        session_id
    ):

        net_profit = self.get_net_profit(
            session_id
        )

        crew = self.get_crew_members(
            session_id
        )

        crew_count = len(crew)

        if crew_count == 0:
            return 0

        return int(
            net_profit / crew_count
        )


    def save_sale_value(
        self,
        session_id,
        sale_value
    ):

        self.cursor.execute("""
        UPDATE sessions
        SET sale_value = ?
        WHERE id = ?
        """, (
            sale_value,
            session_id
        ))

        self.connection.commit()


    def mark_session_sold(
        self,
        session_id,
        sale_value
    ):

        self.cursor.execute("""
        UPDATE sessions
        SET
            status = 'SOLD',
            sale_value = ?
        WHERE id = ?
        """, (
            sale_value,
            session_id
        ))

        self.connection.commit()
        
    def get_sold_sessions(self):

        self.cursor.execute("""
        SELECT
            id,
            ship,
            status,
            sale_value
        FROM sessions
        WHERE status = 'SOLD'
        ORDER BY id DESC
        """)

        return self.cursor.fetchall()
    
    def get_sold_session_count(self):

        self.cursor.execute("""
        SELECT COUNT(*)
        FROM sessions
        WHERE status = 'SOLD'
        """)

        return self.cursor.fetchone()[0]
    
    def get_ready_for_sale_count(self):

        self.cursor.execute("""
        SELECT COUNT(*)
        FROM sessions
        WHERE status = 'REFINERY_COMPLETED'
        """)

        return self.cursor.fetchone()[0]
    
    def get_total_sales_value(self):

        self.cursor.execute("""
        SELECT COALESCE(
            SUM(sale_value),
            0
        )
        FROM sessions
        """)

        return self.cursor.fetchone()[0]
    
    def get_global_material_total(
        self,
        material_type
    ):

        self.cursor.execute("""
        SELECT COALESCE(
            SUM(amount),
            0
        )
        FROM session_materials
        WHERE material_type = ?
        """, (
            material_type,
        ))

        return self.cursor.fetchone()[0]
    
    def get_total_profit(self):

        self.cursor.execute("""
        SELECT COALESCE(
            SUM(sale_value),
            0
        )
        FROM sessions
        """)

        total_sales = self.cursor.fetchone()[0]

        self.cursor.execute("""
        SELECT COALESCE(
            SUM(amount),
            0
        )
        FROM costs
        """)

        total_costs = self.cursor.fetchone()[0]

        return total_sales - total_costs
    
    def get_active_session_count(self):

        self.cursor.execute("""
        SELECT COUNT(*)
        FROM sessions
        WHERE status = 'ACTIVE'
        """)

        return self.cursor.fetchone()[0]
    
    def get_total_session_count(self):

        self.cursor.execute("""
        SELECT COUNT(*)
        FROM sessions
        """)

        return self.cursor.fetchone()[0]

    def add_material(
        self,
        session_id,
        material_type,
        amount
    ):

        self.cursor.execute("""
        INSERT INTO session_materials(
            session_id,
            material_type,
            amount
        )
        VALUES(?,?,?)
        """, (
            session_id,
            material_type,
            amount
        ))

        self.connection.commit()

    def get_session_materials(
        self,
        session_id
    ):

        self.cursor.execute("""
        SELECT
            material_type,
            amount
        FROM session_materials
        WHERE session_id = ?
        """, (session_id,))

        return self.cursor.fetchall()
    
    def get_material_total(
        self,
        session_id,
        material_type
    ):

        self.cursor.execute("""
        SELECT COALESCE(
            SUM(amount),
            0
        )
        FROM session_materials
        WHERE session_id = ?
        AND material_type = ?
        """, (
            session_id,
            material_type
        ))

        return self.cursor.fetchone()[0]
    
    def get_total_cm(
        self,
        session_id
    ):

        self.cursor.execute("""
        SELECT COALESCE(
            SUM(amount),
            0
        )
        FROM session_materials
        WHERE session_id = ?
        AND material_type = 'CM'
        """, (session_id,))

        result = self.cursor.fetchone()[0]

        print(
            "GET_TOTAL_CM:",
            session_id,
            result
        )

        return result
    
    def get_session_total_scu(
        self,
        session_id
    ):

        self.cursor.execute("""
        SELECT COALESCE(
            SUM(amount),
            0
        )
        FROM session_materials
        WHERE session_id = ?
        """, (session_id,))

        return self.cursor.fetchone()[0]
    
    def get_sessions_ready_for_sale(self):

        self.cursor.execute("""
        SELECT
            id,
            ship
        FROM sessions
        WHERE status = 'READY_FOR_SALE'
        ORDER BY id DESC
        """)

        return self.cursor.fetchall()
    
    def mark_ready_for_sale(
        self,
        session_id
    ):

        self.cursor.execute("""
        UPDATE sessions
        SET status = 'READY_FOR_SALE'
        WHERE id = ?
        """, (session_id,))

        self.connection.commit()

    def add_refinery_job(
        self,
        session_id,
        material_type,
        input_scu,
        ready_time
    ):

        self.cursor.execute("""
        INSERT INTO refinery_jobs(
            session_id,
            material_type,
            input_scu,
            output_cm,
            status,
            created_at,
            ready_time
        )
        VALUES(
            ?, ?, ?, 0,
            'PROCESSING',
            CURRENT_TIMESTAMP,
            ?
        )
        """, (
            session_id,
            material_type,
            input_scu,
            ready_time
        ))

        self.connection.commit()
        
    def get_refinery_jobs(
        self,
        session_id
    ):

        self.cursor.execute("""
        SELECT
            refinery_jobs.id,
            refinery_jobs.material_type,
            refinery_jobs.input_scu,
            refinery_jobs.output_cm,
            refinery_jobs.status,
            refinery_jobs.created_at,
            refinery_jobs.ready_time,
            sessions.ship,
            sessions.start_time
        FROM refinery_jobs
        INNER JOIN sessions
        ON refinery_jobs.session_id = sessions.id
        WHERE session_id = ?
        AND refinery_jobs.status != 'COLLECTED'
        ORDER BY refinery_jobs.id DESC
        """, (session_id,))

        return self.cursor.fetchall()
    
    def collect_refinery_job(
        self,
        job_id
    ):

        self.cursor.execute("""
        SELECT session_id
        FROM refinery_jobs
        WHERE id = ?
        """, (job_id,))

        session_id = self.cursor.fetchone()[0]

        self.cursor.execute(
            """
            UPDATE refinery_jobs
            SET status = 'COLLECTED'
            WHERE id = ?
            """,
            (job_id,)
        )
        
        self.cursor.execute("""
        SELECT COUNT(*)
        FROM refinery_jobs
        WHERE session_id = ?
        AND status != 'COLLECTED'
        """, (session_id,))

        remaining_jobs = self.cursor.fetchone()[0]

        print(
            "REMAINING JOBS:",
            remaining_jobs
        )
        
        if remaining_jobs == 0:

            self.cursor.execute("""
            UPDATE sessions
            SET status = 'REFINERY_COMPLETED'
            WHERE id = ?
            """, (session_id,))
        
        self.connection.commit()
    
    def mark_refinery_job_ready(
        self,
        job_id,
        output_cm
    ):

        self.cursor.execute("""
        UPDATE refinery_jobs
        SET
            status = 'READY',
            output_cm = ?
        WHERE id = ?
        """, (
            output_cm,
            job_id
        ))

        self.connection.commit()